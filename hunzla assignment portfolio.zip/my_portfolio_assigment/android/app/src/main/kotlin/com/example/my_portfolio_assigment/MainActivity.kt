package com.example.my_portfolio_assigment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
